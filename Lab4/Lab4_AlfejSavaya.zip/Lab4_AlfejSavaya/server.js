// Student Name: Alfej Savaya
// Student ID: 118823210
// Student Email: aasavaya@myseneca.ca

const Sequelize = require('sequelize');

// set up sequelize to point to our postgres database
var sequelize = new Sequelize('wpgochjg', 'wpgochjg', 'iMq_3OVloEqI7fF8T65gFbnB8iSVpZwq', {
    host: 'peanut.db.elephantsql.com',
    dialect: 'postgres',
    port: 5432,
    dialectOptions: {
        ssl: { rejectUnauthorized: false }
    },
    query: { raw: true }
});

// Define a "Person" model

var Person = sequelize.define('Person', {
    First_Name: Sequelize.STRING,  // first Person
    Last_Name: Sequelize.STRING, // Last Person
    age: Sequelize.INTEGER, // Age
});

sequelize.sync().then(function () {

    Person.create({
        First_Name: "Alfej",
        Last_Name: "Savaya",
        Age: 21
    }).then(function(){ console.log("Alfej Savaya created")});

});
